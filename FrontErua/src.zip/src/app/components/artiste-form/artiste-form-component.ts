import { Component } from '@angular/core';

@Component({
  selector: 'app-artiste-form',
  standalone: true,
  imports: [],
  templateUrl: './artiste-form-component.html',
  styleUrl: './artiste-form-component.scss'
})
export class ArtisteFormComponent {

}
