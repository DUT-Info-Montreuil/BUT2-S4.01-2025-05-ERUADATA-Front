import { Component } from '@angular/core';

@Component({
  selector: 'app-artiste-detail',
  standalone: true,
  imports: [],
  templateUrl: './artiste-detail-component.html',
  styleUrl: './artiste-detail-component.scss'
})
export class ArtisteDetailComponent {

}
