import { Component } from '@angular/core';

@Component({
  selector: 'app-edition',
  standalone: true,
  imports: [],
  templateUrl: './editioncomponent.html',
  styleUrl: './editioncomponent.scss'
})
export class EditionComponent {

}
