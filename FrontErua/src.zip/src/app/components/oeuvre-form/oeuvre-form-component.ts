import { Component } from '@angular/core';

@Component({
  selector: 'app-oeuvre-form',
  standalone: true,
  imports: [],
  templateUrl: './oeuvre-form-component.html',
  styleUrl: './oeuvre-form-component.scss'
})
export class OeuvreFormComponent {

}
