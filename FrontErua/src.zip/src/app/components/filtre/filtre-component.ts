import { Component } from '@angular/core';

@Component({
  selector: 'app-filtre',
  standalone: true,
  imports: [],
  templateUrl: './filtre-component.html',
  styleUrl: './filtre-component.scss'
})
export class FiltreComponent {

}
