/*import { Component } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [],
  templateUrl: './sidebarcomponent.html',
  styleUrl: './sidebarcomponent.scss'
})
export class Sidebarcomponent {
  activeItem: string = 'accueil';

  setActive(item: string): void {
    this.activeItem = item;
  }
} */

import { Component, Input } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './sidebarcomponent.html',
  styleUrls: ['./sidebarcomponent.scss']
})
export class Sidebarcomponent {
  @Input() visible = false;

  menuItems = [
    { label: 'Accueil', path: '/accueil' },
    { label: 'Édition', path: '/edition' },
    { label: 'Généalogie', path: '/genealogie' }
  ];
}
