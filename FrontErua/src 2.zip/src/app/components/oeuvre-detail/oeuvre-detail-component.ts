import { Component } from '@angular/core';

@Component({
  selector: 'app-oeuvre-detail',
  standalone: true,
  imports: [],
  templateUrl: './oeuvre-detail-component.html',
  styleUrl: './oeuvre-detail-component.scss'
})
export class OeuvreDetailComponent {

}
